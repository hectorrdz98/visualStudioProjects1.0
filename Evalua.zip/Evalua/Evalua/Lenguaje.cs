﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Evalua
{
    class Lenguaje : Sintaxis
    {
        List<Variable> variables;
        public Lenguaje() : base()
        {
            variables = new List<Variable>();
        }
        public Lenguaje(string filePath) : base(filePath)
        {
            variables = new List<Variable>();
        }

        public void Programa()
        {
            Librerias();
            Main();
        }

        private void Librerias()
        {
            Match("using");
            Match(c.Identificador);
            if (getContenido() == ".")
                SubLibrerias();
            Match(c.FinSentencia);
            if (getContenido() == "using")
                Librerias();
        }

        private void SubLibrerias()
        {
            Match(".");
            Match(c.Identificador);
            if (getContenido() == ".")
                SubLibrerias();
        }

        private void Main()
        {
            Match("namespace");
            Match(c.Identificador);
            Match(c.InicioBloque);
            {
                Match("class");
                Match("Program");
                Match(c.InicioBloque);
                {
                    Match("static");
                    Match("void");
                    Match("Main");
                    Match("(");
                    Match("string");
                    Match("[");
                    Match("]");
                    Match("args");
                    Match(")");
                    Match(c.InicioBloque);
                    {
                        Instrucciones();
                    }
                    Match(c.FinBloque);
                }
                Match(c.FinBloque);
            }
            Match(c.FinBloque);
        }

        private void Instrucciones()
        {
            if (getContenido() == "Console")
            {
                Match(getContenido());
                Match(".");
                switch(getContenido())
                {
                    case "WriteLine":
                    case "Write":
                        {
                            Match(getContenido());
                            Match("(");
                            if (getClasificacion() == c.Cadena) Match(getClasificacion());
                            else Match(c.Identificador);
                            Match(")");
                        } break;
                    case "ReadLine":
                    case "Read":
                    case "ReadKey":
                        {
                            Match(getContenido());
                            Match("(");
                            Match(")");
                        }
                        break;
                    default:
                        {
                            try
                            {
                                log.WriteLine(DateTime.Now.ToString("dd/MM/yy HH:mm") + " - Error de sintaxis: Se espera una entrada o salida");
                                throw new MyException("Error de sintaxis: Se espera", "una entrada o salida");
                            }
                            finally { closeFiles(); }
                        }
                }
                Match(c.FinSentencia);
            }
            else if (getClasificacion() == c.TipoDato)
            {
                Variable.t tipoVariable = Variable.stringToT(getContenido());
                Match(c.TipoDato);
                ListaDeIdentificadores(tipoVariable);
                Match(c.FinSentencia);
            }
            else if (getClasificacion() == c.Constante)
            {
                Match(c.Constante);
                Variable.t tipoVariable = Variable.stringToT(getContenido());
                Match(c.TipoDato);
                ListaDeConstantes(tipoVariable);
                Match(c.FinSentencia);
            }

            if (getClasificacion() != c.FinBloque)
                Instrucciones();

            // tipo_dato id = Expresion;
            // tipo_dato id = Console.ReadLine();
            // tipo_dato id = Console.Read();
            // if
        }

        private void ListaDeIdentificadores(Variable.t tipoVariable)
        {
            string variable = getContenido();
            Match(c.Identificador);
            if (!existeVariable(variable))
            {
                string valor = "";
                if (getClasificacion() == c.Asignacion)
                {
                    Match(c.Asignacion);
                    if (getContenido() == "Console")
                    {
                        Match("Console");
                        Match(".");
                        if (getContenido() == "ReadLine") Match("ReadLine");
                        else if (getContenido() == "Read") Match("Read");
                        else Match("ReadKey");
                        Match("(");
                        Match(")");
                    }
                    /* 
                    else 
                    {
                        valor = ExpresionMatematica();
                    }
                    */
                }

                variables.Add(new Variable(variable, tipoVariable, valor, false));

                if (getContenido() == ",")
                {
                    Match(",");
                    ListaDeIdentificadores(tipoVariable);
                }
            }
            else
            {
                try
                {
                    log.WriteLine(DateTime.Now.ToString("dd/MM/yy HH:mm") + " - Error de sintaxis: La variable " + variable + " está duplicada");
                    throw new MyException("Error de sintaxis: La variable " + variable + " está duplicada");
                }
                finally { closeFiles(); }
            }
            
        }

        private void ListaDeConstantes(Variable.t tipoVariable)
        {
            Match(c.Identificador);
            Match(c.Asignacion);
            // ExpresionMatematica();
            if (getContenido() == ",")
            {
                Match(",");
                ListaDeConstantes(tipoVariable);
            }
        }

        private bool existeVariable(string nombre)
        {
            foreach(Variable v in variables)
            {
                if (v.getNombre() == nombre) return true;
            }
            return false;
        }

    }
}
